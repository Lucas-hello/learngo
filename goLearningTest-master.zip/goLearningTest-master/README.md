# goLearningTest
#### golang学习练习题
初学`go`一直找不到合适的练习，最近在一本书中发现了一些练习题，整理，分享给大家



