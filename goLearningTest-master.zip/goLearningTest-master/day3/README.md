#### day3
- 使用 interface 的 map 函数
  1. 使用练习day2中的map()函数，利用 interface 使其更加通用。让它至少能同时工作于
  int 和 string
-  cat
    1. 编写一个程序，模仿 Unix 的 cat 程序。对于不知道这个程序的人来说，下面的
    调用显示了文件 的内容：
 
    2. 使其支持 n 开关，用于输出每行的行号