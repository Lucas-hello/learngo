#### day4
-  修改在练习 day1中的第一个程序，换句话说，主体中调用的函数现在是一个
  goroutine 并且使用 channel 通讯
 - 实现斐波拉契 使用channel。