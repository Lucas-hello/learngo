package day4

import "testing"

func TestFirst(t *testing.T) {
	First()
}

func TestRunfib(t *testing.T) {
	Runfib()
}